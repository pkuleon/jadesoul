/*
    NetLink Sockets: Networking C++ library
    Copyright 2010 Pedro Francisco Pareja Ruiz (PedroPareja@Gmail.com)

    This file is part of NetLink Sockets.

    NetLink Sockets is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NetLink Sockets is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NetLink Sockets. If not, see <http://www.gnu.org/licenses/>.

*/

#include "nlRPC.h"

bool NLRPC::initDone = false;
NLDataBlockDef* NLRPC::DATABLOCK_DEF_EXEC_REQUEST = NULL;
NLDataBlockDef* NLRPC::DATABLOCK_DEF_THROW_EXCEPTION = NULL;
NLDataBlockDef* NLRPC::DATABLOCK_DEF_VOID = NULL;


void initConstants() {

    if(!NLRPC::initDone) {

        NLRPC::DATABLOCK_DEF_EXEC_REQUEST = new NLDataBlockDef(NLRPC::DATABLOCK_ID_EXEC_REQUEST);
            NLRPC::DATABLOCK_DEF_EXEC_REQUEST->addType("functionId", NLDataType::UNSIGNED_16);
            NLRPC::DATABLOCK_DEF_EXEC_REQUEST->addType("parameters", NLDataType::DATA_BLOCK);
            NLRPC::DATABLOCK_DEF_EXEC_REQUEST->addType("udpPort", NLDataType::INT_16);

        NLRPC::DATABLOCK_DEF_THROW_EXCEPTION = new NLDataBlockDef(NLRPC::DATABLOCK_ID_THROW_EXCEPTION);
            NLRPC::DATABLOCK_DEF_THROW_EXCEPTION->addType("code", NLDataType::INT_16);
            NLRPC::DATABLOCK_DEF_THROW_EXCEPTION->addType("text", NLDataType::STRING);

        NLRPC::DATABLOCK_DEF_VOID = new NLDataBlockDef(NLRPC::DATABLOCK_ID_VOID);


        NLRPC::initDone = true;

    }
}


void NLRPCCmd::paramDataBlockId(unsigned paramDataBlockId) {

    _paramDataBlockId = paramDataBlockId;
}

unsigned NLRPCCmd::paramDataBlockId() {

    return(_paramDataBlockId);
}

// NLRPCServer::Listen() related functionality:

    class CmdOnAccept : public NLCmdOnAccept {

            void onAcceptReady(NLSocket* socket, NLSocketGroup* sGroup, void* reference) {

                    NLSocket* newSocket = socket->accept();
                    if(newSocket != NULL)
                        sGroup->addSocket(newSocket);
            }
    };


    class CmdOnRead : public NLCmdOnRead {

            void onReadReady(NLSocket* socket, NLSocketGroup* sGroup, void* reference) {

                NLRPCServer* rpcServer = (NLRPCServer*)reference;
                rpcServer->processRequest(socket);
            }
    };


    class CmdOnDisconnect : public NLCmdOnDisconnect {

            void onDisconnect(NLSocket* socket, NLSocketGroup* sGroup, void* reference) {

                sGroup->removeSocket(socket);
                delete socket;
            }
    };
// ----------------------------------------------

NLRPCServer::NLRPCServer(int port, int protocol, int ipVer) : _socket(port, protocol, ipVer) {

    initConstants();

    _dataBlockDefsSet.add(NLRPC::DATABLOCK_DEF_EXEC_REQUEST);
    _dataBlockDefsSet.add(NLRPC::DATABLOCK_DEF_VOID);

    _connections.addSocket(&_socket);

    CmdOnRead* cmdRead = new CmdOnRead();
    _connections.setCmdOnRead(cmdRead);

    if(protocol == NLProtocol::TCP) {
        CmdOnAccept* cmdAccept = new CmdOnAccept();
        _connections.setCmdOnAccept(cmdAccept);
        CmdOnDisconnect* cmdOnDisconnect = new CmdOnDisconnect();
        _connections.setCmdOnDisconnect(cmdOnDisconnect);
    }

}

void NLRPCServer::addFunction(unsigned functionId, NLDataBlockDef* paramDataBlockDef, NLRPCCmd* cmd) {

    _dataBlockDefsSet.add(paramDataBlockDef);
    cmd->paramDataBlockId(paramDataBlockDef->id());
    _cmds[functionId] = cmd;
}

void NLRPCServer::removeFunction(unsigned functionId) {

    _cmds.erase(functionId);
}


void NLRPCServer::listen(unsigned milisecs) {

    _connections.listen(milisecs, this);
}

void NLRPCServer::processRequest(NLSocket* source) {

    string sourceHost, *pointerSourceHost;

    if(_socket.protocol()== NLProtocol::UDP)
        pointerSourceHost = &sourceHost;
    else
        pointerSourceHost = NULL;

    if(NLDataBlock::checkRawDataBlock(source->rawRead(NLSocket::DEFAULT_BUFFER_SIZE, pointerSourceHost))) {

        unsigned lengthOfRead = 0;
        NLDataBlock dataBlock(source->rawReadBuffer(), &_dataBlockDefsSet, &lengthOfRead);
        source->rawReadBuffer()->erase(source->rawReadBuffer()->begin(), source->rawReadBuffer()->begin() + lengthOfRead);

        if(dataBlock.id() == NLRPC::DATABLOCK_ID_EXEC_REQUEST) {

                unsigned functionId = dataBlock.getUnsigned("functionId");
                NLDataBlock* params = dataBlock.getSubDataBlock("parameters");
                int udpPort = dataBlock.getInt("udpPort");

                map<unsigned, NLRPCCmd*>::iterator it = _cmds.find(functionId);

                NLRPCCmd* cmd = NULL;

                if (it!= _cmds.end())
                    cmd = it->second;

                if (it == _cmds.end())
                    sendException(source, NLRPC::ERROR_FUNCTION_NOT_FOUND, "Called Function was not found", sourceHost, udpPort);
                else if (params->id() != cmd->paramDataBlockId())
                    sendException(source, NLRPC::ERROR_WRONG_PARAMETERS, "Wrong function parameter datablock", sourceHost, udpPort);
                else {

                    NLDataBlock* answer = cmd->exec(params);
                    vector<unsigned char>* answerRaw = answer->encode();
                    sendAnswer(source, answerRaw, sourceHost, udpPort);
                    delete answer;
                    delete answerRaw;
                }

        }
        else
            sendException(source, NLRPC::ERROR_EXEC_REQUEST_EXPECTED, "Server expected a exec request datablock", sourceHost);

    dataBlock.deleteSubDataBlocks();

    } //if
}


void NLRPCServer::sendAnswer(NLSocket* socket, vector<unsigned char>* raw, string udpHost, int udpPort) {

    if(socket->protocol() == NLProtocol::UDP) {
        if (udpPort > 0)
            socket->rawSendTo(udpHost, udpPort, raw);
    }
    else {
        socket->rawSend(raw);
    }
}

void NLRPCServer::sendException(NLSocket* socket, int code, string text,string udpHost, int udpPort) {

        NLDataBlock exceptionDB(NLRPC::DATABLOCK_DEF_THROW_EXCEPTION);
        exceptionDB.setInt("code", code);
        exceptionDB.setString("text", text);
        sendAnswer(socket, exceptionDB.encode(), udpHost, udpPort);
}

// NLRPCClient Listening related functions

    class ClientOnRead : public NLCmdOnRead {

        void onReadReady(NLSocket* socket, NLSocketGroup* sGroup, void* reference) {

                vector<unsigned char>* raw = socket->rawRead();
                cout << "\nRespuesta Leida: ";
                if (NLDataBlock::checkRawDataBlock(raw)) {
                    NLRPCClient* rpcClient = (NLRPCClient*) reference;
                    unsigned length = 0;
                    rpcClient->_lastAnswer = new NLDataBlock(raw, &rpcClient->_defs, &length);
                    raw->erase(raw->begin(), raw->begin() + length);
                }
        }
    };


NLRPCClient::NLRPCClient(string host, int port, int protocol, int ipVer, int UDPListenPort) : _socket(host, port, protocol, ipVer) {

    initConstants();

    _sGroup.addSocket(&_socket);

    if (protocol == NLProtocol::UDP) {
        _udpListenSocket = new NLSocket(UDPListenPort, protocol, ipVer);
        _sGroup.addSocket(_udpListenSocket);
    }
    else
        _udpListenSocket = NULL;

    _defs.add(NLRPC::DATABLOCK_DEF_THROW_EXCEPTION);
    _defs.add(NLRPC::DATABLOCK_DEF_VOID);

    ClientOnRead* clientOnRead = new ClientOnRead();
    _sGroup.setCmdOnRead(clientOnRead);

}


void NLRPCClient::addDataBlockDef(NLDataBlockDef* def) {

    _defs.add(def);
}


NLDataBlock* NLRPCClient::exec(unsigned functionId, NLDataBlock* parameters, unsigned responseTimeOut) {

    _lastAnswer = NULL;

    NLDataBlock request(NLRPC::DATABLOCK_DEF_EXEC_REQUEST);
    request.setUnsigned("functionId", functionId);
    request.setSubDataBlock("parameters", parameters);

    int udpPort = -1;
    if(_udpListenSocket!= NULL)
        udpPort = _udpListenSocket->port();
    request.setInt("udpPort", udpPort);

    vector<unsigned char>* rawRequest = request.encode();

    _socket.rawSend(rawRequest);

    delete rawRequest;

    unsigned timeOutTime = getTime() + responseTimeOut;

    while(_lastAnswer==NULL && getTime() < timeOutTime && _sGroup.listenUntilOne(timeOutTime - getTime(), this)) {}

    checkException();

    return(_lastAnswer);
}

NLDataBlock* NLRPCClient::getAnswer(unsigned timeOut) {

    _lastAnswer = NULL;

    unsigned timeOutTime = getTime() + timeOut;

    while(_lastAnswer==NULL && getTime() < timeOutTime && _sGroup.listenUntilOne(timeOutTime - getTime(), this)) {}

    checkException();

    return(_lastAnswer);

}

void NLRPCClient::checkException() {

    if(_lastAnswer!=NULL) {

        if(_lastAnswer->id()== NLRPC::DATABLOCK_ID_THROW_EXCEPTION) {

                int code(_lastAnswer->getInt("code"));
                string text(_lastAnswer->getString("text"));
                throw new NLException(code, text);
        } //if

    } //if
}

