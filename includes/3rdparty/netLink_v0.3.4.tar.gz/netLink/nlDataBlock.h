/*
    NetLink Sockets: Networking C++ library
    Copyright 2010 Pedro Francisco Pareja Ruiz (PedroPareja@Gmail.com)

    This file is part of NetLink Sockets.

    NetLink Sockets is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NetLink Sockets is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NetLink Sockets. If not, see <http://www.gnu.org/licenses/>.

*/

#ifndef __NL_DATA_BLOCK
#define __NL_DATA_BLOCK

#include "nlException.h"
#include "util/pack.h"

#include <vector>
#include <map>
#include <string>

using namespace std;


class NLDataType {

   public:

        static const int DATA_BLOCK = 13;

        static const int CHAR = 1;
        static const int UNSIGNED_CHAR = 2;
        static const int STRING = 3;
        static const int INT_16 = 4;        // int
        static const int INT_32 = 5;        // long
        static const int INT_64 = 6;        // long long
        static const int UNSIGNED_16 = 7;
        static const int UNSIGNED_32 = 8;
        static const int UNSIGNED_64 = 9;
        static const int FLOAT = 10;
        static const int DOUBLE = 11;
        static const int DOUBLE_64 = 12;    // long double

        //static const int ERROR = 0;
        static const int MIN_TYPE = 1;
        static const int MAX_TYPE = 13;

};


class NLDataBlockDef {

    protected:

        unsigned                    _id;
        vector<string>              _dataName;
        vector<int>                 _dataType;
        vector<NLDataBlockDef*>     _blockDefs;

    public:

        NLDataBlockDef(unsigned id);                                                    // WARNING: id SHOULD BE above 1000 to avoid collisions with lib related datablock ids.
        NLDataBlockDef(unsigned id, int type, unsigned n, NLDataBlockDef* def = NULL);  // for vectors. def is used only if type is DataBlock

        unsigned addType(int type, NLDataBlockDef* def = NULL);     // returns the position of this new type in the dataBlockDefinition; set def in case type = DATA_BLOCK and the type of dataBlock is fixed
        unsigned addType(string name, int type, NLDataBlockDef* def = NULL);
        int getType(unsigned pos);  //returns 0 on error
        int getType(string name);   //returns 0 on error
        unsigned getPos(string name);

        NLDataBlockDef* getSubDataBlockDef(unsigned pos);

        unsigned id();

        unsigned size();

    protected:

        void checkType(int type);

    public:

        static const int ERROR_NAME_NOT_FOUND = 30;
        static const int ERROR_BAD_TYPE = 31;
        static const int ERROR_BAD_POSITION = 32;
        static const int ERROR_NOT_DATABLOCK_POSITION = 33;
};


class NLDataBlockDefSet {

    protected:

        map<unsigned, NLDataBlockDef*> _defs;

    public:

        NLDataBlockDefSet();
        NLDataBlockDefSet(const NLDataBlockDefSet& dSet);

        NLDataBlockDefSet& operator = (const NLDataBlockDefSet& dSet);

        void add(NLDataBlockDef* def);
        NLDataBlockDef* get(unsigned id);       // returns NULL in case 'id' isn't found

};



class NLDataBlock {


    protected:

        NLDataBlockDef*     _blockDef;
        vector<void*>       _data;

    public:

        NLDataBlock(NLDataBlockDef* def);
        NLDataBlock(vector<unsigned char>* datablockRaw, NLDataBlockDefSet* defs, unsigned* lengthOfRead = NULL);        // lengthOfRead is set returns the amount of chars of the vector that have been read to build the dataBlock (in a vector of chars can be several dataBlocks)
        NLDataBlock(const NLDataBlock& dB);     // TODO

        ~NLDataBlock();

        NLDataBlock& operator = (const NLDataBlock& dB);    // TODO

        void deleteSubDataBlocks();

        vector<unsigned char>* encode(unsigned bufferSize = ENCODE_BUFFER_SIZE);

        void set(unsigned pos, void* data);     // This functions for dataBlock type stores a reference. For the rest of the types stores a copy.
        void set(string name, void* data);

        void setInt(unsigned pos, long long data);  // works for all INT types (CHAR, INT_16, INT_32, INT_64)
        void setInt(string name, long long data);

        void setDouble(unsigned pos, long double data);     // works for all double types (FLOAT, DOUBLE, DOUBLE_64)
        void setDouble(string name, long double data);

        void setUnsigned(unsigned pos, unsigned long long data);    // works for all UNSIGNED types (UNSIGNED_CHAR, UNSIGNED_16, UNSIGNED_32, UNSIGNED_64)
        void setUnsigned(string name, unsigned long long data);

        void setString(unsigned pos, string data);
        void setString(string name, string data);

        void setSubDataBlock(unsigned pos, NLDataBlock* data);
        void setSubDataBlock(string name, NLDataBlock* data);

        void* get(unsigned pos);
        void* get(string name);

        long long getInt(unsigned pos);
        long long getInt(string name);

        long double getDouble(unsigned pos);
        long double getDouble(string name);

        unsigned long long getUnsigned(unsigned pos);
        unsigned long long getUnsigned(string name);

        string getString(unsigned pos);
        string getString(string name);

        NLDataBlock* getSubDataBlock(unsigned pos);
        NLDataBlock* getSubDataBlock(string name);

        static bool checkRawDataBlock(vector<unsigned char>* dataBlockRaw);      // Check if there's anypart of the datablock is missing (returns true in case of everything right)

        unsigned id();

    protected:

        void buildFromArray(unsigned char* rawArray, NLDataBlockDefSet* defs, unsigned* lengthOfRead);
        NLDataBlock();
        void freeMemory();


    public:

        static const unsigned ENCODE_BUFFER_SIZE = 1024;

        static const int ERROR_NAME_NOT_FOUND = NLDataBlockDef::ERROR_NAME_NOT_FOUND;
        static const int ERROR_BAD_TYPE = NLDataBlockDef::ERROR_BAD_TYPE;
        static const int ERROR_BAD_POSITION = NLDataBlockDef::ERROR_BAD_POSITION;
        static const int ERROR_STRING_TOO_BIG = 40;
        static const int ERROR_UNSET_DATA = 41;
        static const int ERROR_DATABLOCKDEF_NOT_FOUND = 42;
        static const int ERROR_BAD_RAW_BLOCK_SIZE = 43;
        static const int ERROR_BAD_DATABLOCK_TYPE = 44;

};


#endif
