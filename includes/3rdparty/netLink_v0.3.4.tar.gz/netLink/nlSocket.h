/*
    NetLink Sockets: Networking C++ library
    Copyright 2010 Pedro Francisco Pareja Ruiz (PedroPareja@Gmail.com)

    This file is part of NetLink Sockets.

    NetLink Sockets is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NetLink Sockets is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NetLink Sockets. If not, see <http://www.gnu.org/licenses/>.

*/

#ifndef __NL_SOCKET
#define __NL_SOCKET

#include <string>
#include <vector>

#include "util/util.h"
#include "nlCore.h"
#include "nlException.h"

using namespace std;

class NLSocket {

    protected:

        int _socket;
        bool _isServer;
        string _readBuffer;
        vector<unsigned char> _rawReadBuffer;

        bool _isDisconnected;
        bool _blocking;

        int _protocol;
        int _ipVer;
        string _host;
        int _port;

    public:

        NLSocket(string host, int port, int protocol = NLProtocol::TCP, int ipVer = NLIpVer::Any);      // Client socket (connected)
        NLSocket(int port, int protocol = NLProtocol::TCP, int ipVer = NLIpVer::Any, int listenQueue = DEFAULT_LISTEN_QUEUE);                   // Server socket (listening)
        ~NLSocket();

        NLSocket* accept();

        string& read(unsigned bufferSize = DEFAULT_BUFFER_SIZE, string* hostFrom = NULL);      // Read. If hostFrom is set, it stores there the address of the sender host (useful for UDP packets)
        string& readBuffer();
        void clearReadBuffer();

        vector<unsigned char>* rawRead(unsigned bufferSize = DEFAULT_BUFFER_SIZE, string* hostFrom = NULL);  // returns a reference to the socket internal buffer (do not free, use clearRawReadBuffer instead)
        vector<unsigned char>* rawReadBuffer();                                     // returns a reference to the socket internal buffer (do not free, use clearRawReadBuffer instead)
        void clearRawReadBuffer();


        void send(string data);                                     // SendAll (Both types [TCP and UDP])
        void sendTo(string host, int port, string data);            // Only for UDP

        void rawSend(vector<unsigned char>* data);
        void rawSendTo(string host, int port, vector<unsigned char>* data);

        void operator << (string &data);
        void operator << (vector<unsigned char>& data);

        void operator >> (string& output);                          // the socket buffer is copied into output (socket buffer is cleared)
        void operator >> (vector<unsigned char>& output);           // the socket buffer is copied into output (socket buffer is cleared)


        bool isDisconnected();

        int protocol();
        string host();
        int port();
        bool isServer();

        // Advanced ...........

        void blocking(bool blck);
        bool blocking();

        int handle();

        // Constants

        static const int DEFAULT_BUFFER_SIZE = 1024;
        static const int DEFAULT_LISTEN_QUEUE = 10;


        // Error consts

        static const int ERROR_IPVER_BAD_VALUE = 1;
        static const int ERROR_PROTOCOL_BAD_VALUE = 2;
        static const int ERROR_SETTING_ADDR_INFO = 3;
        static const int ERROR_CAN_NOT_CONNECT = 4;
        static const int ERROR_SET_SOCK_OPT = 5;
        static const int ERROR_CAN_NOT_BIND = 6;
        static const int ERROR_CAN_NOT_LISTEN = 7;
        static const int ERROR_SOCKET_NOT_SERVER = 8;
        static const int ERROR_SOCKET_NOT_TCP = 9;
        static const int ERROR_SOCKET_DISCONNECTED = 10;
        static const int ERROR_CAN_NOT_SEND = 11;
        static const int ERROR_SOCKET_NOT_UDP = 12;
        static const int ERROR_CAN_NOT_SET_FLAGS = 13;


    protected:

        NLSocket(int handle, string host, int ipVer);

        static void close(int handler);

};


#endif
