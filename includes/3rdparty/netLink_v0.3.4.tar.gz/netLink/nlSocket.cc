/*
    NetLink Sockets: Networking C++ library
    Copyright 2010 Pedro Francisco Pareja Ruiz (PedroPareja@Gmail.com)

    This file is part of NetLink Sockets.

    NetLink Sockets is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NetLink Sockets is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NetLink Sockets. If not, see <http://www.gnu.org/licenses/>.

*/

#include "nlSocket.h"

// Aux Functions


// get sockaddr, IPv4 or IPv6:
// This function is from Brian “Beej Jorgensen” Hall: Beej's Guide to Network Programming.
void *get_in_addr(struct sockaddr *sa)
{
    if (sa->sa_family == AF_INET) {
        return &(((struct sockaddr_in*)sa)->sin_addr);
    }
    return &(((struct sockaddr_in6*)sa)->sin6_addr);
}



NLSocket::NLSocket(string host, int port, int protocol, int ipVer) : _host(host) {

    int status;
    struct addrinfo hints;
    struct addrinfo *res;
    memset(&hints, 0, sizeof(hints));

    switch(ipVer) {

        case NLIpVer::IPv4  :   hints.ai_family = AF_INET;
                                break;
        case NLIpVer::IPv6  :   hints.ai_family = AF_INET6;
                                break;
        case NLIpVer::Any   :   hints.ai_family = AF_UNSPEC;
                                break;
        default             :   throw new NLException(ERROR_IPVER_BAD_VALUE, "IpVer doesn't have a correct value");
    } // switch

    switch(protocol) {

        case NLProtocol::TCP    :   hints.ai_socktype = SOCK_STREAM;
                                    break;
        case NLProtocol::UDP    :   hints.ai_socktype = SOCK_DGRAM;
                                    break;
        default                 :   throw new NLException(ERROR_PROTOCOL_BAD_VALUE, "protocol doesn't have a correct value");

    } //switch

    string portStr = IntToString(port);
    status = getaddrinfo(host.c_str(), portStr.c_str(), &hints, &res);

    if(status != 0) {
        string errorMsg = "Error setting addrInfo: ";
		#ifndef _MSC_VER
			errorMsg += gai_strerror(status);
		#endif
        throw new NLException(ERROR_SETTING_ADDR_INFO, errorMsg);
    }

    bool connected = false;
    int ai_family;

    // Recorres la lista de soluciones

    while(!connected && res != NULL) {

        _socket = socket(res->ai_family, res->ai_socktype, res->ai_protocol);

        if(_socket != -1) {

            if(protocol == NLProtocol::UDP)
                connected = true;
            else {
                status = connect(_socket, res->ai_addr, res->ai_addrlen);
                if(status != -1)
                    connected = true;
                else
                    close(_socket);
            }
        }

    if(connected)
        ai_family = res->ai_family;

    res = res->ai_next;

    } //while

    if (!connected)
        throw new NLException(ERROR_CAN_NOT_CONNECT, "Error connecting to host");

    _isServer = false;
    _isDisconnected = false;
    _blocking = false;
    _protocol = protocol;
    _ipVer = ipVer;

    if(ipVer == NLIpVer::Any) {
        if(ai_family == AF_INET)
            _ipVer = NLIpVer::IPv4;
        else if(ai_family == AF_INET6)
            _ipVer = NLIpVer::IPv6;
    }

    // host is set
    _port = port;

    freeaddrinfo(res);
}



NLSocket::NLSocket(int port, int protocol, int ipVer, int listenQueue) {

    int status;
    struct addrinfo hints;
    struct addrinfo *res;
    memset(&hints, 0, sizeof(hints));

    hints.ai_flags = AI_PASSIVE;   // <------

    switch(ipVer) {

        case NLIpVer::IPv4  :   hints.ai_family = AF_INET;
                                break;
        case NLIpVer::IPv6  :   hints.ai_family = AF_INET6;
                                break;
        case NLIpVer::Any   :   hints.ai_family = AF_UNSPEC;
                                break;
        default             :   throw new NLException(ERROR_IPVER_BAD_VALUE, "IpVer doesn't have a correct value");
    } // switch

    switch(protocol) {

        case NLProtocol::TCP    :   hints.ai_socktype = SOCK_STREAM;
                                    break;
        case NLProtocol::UDP    :   hints.ai_socktype = SOCK_DGRAM;
                                    break;
        default                 :   throw new NLException(ERROR_PROTOCOL_BAD_VALUE, "protocol doesn't have a correct value");

    } //switch

    string portStr = IntToString(port);
    status = getaddrinfo(NULL, portStr.c_str(), &hints, &res);      // <------

    if(status != 0) {
        string errorMsg = "Error setting addrInfo: ";
		#ifndef _MSC_VER
			errorMsg += gai_strerror(status);
		#endif
        throw new NLException(ERROR_SETTING_ADDR_INFO, errorMsg);
    }

    //Idem ----------------------------------------------------------- (Except for AI_PASSIVE and getaddrinfo)

    bool connected = false;
    int ai_family;

    #ifdef OS_WIN32
        char yes = 1;
    #else
        int yes = 1;
    #endif

    // Recorres la lista de soluciones

    while(!connected && res != NULL) {

        _socket = socket(res->ai_family, res->ai_socktype, res->ai_protocol);

        if(_socket != -1) {

            if (setsockopt(_socket, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1)
                throw new NLException(ERROR_SET_SOCK_OPT, "Error establishing socket options");

            if (bind(_socket, res->ai_addr, res->ai_addrlen) == -1)
                close(_socket);
            else {
                connected = true;
                ai_family = res->ai_family;
            }
        }

        res = res->ai_next;

    } //while

    if(!connected)
        throw new NLException(ERROR_CAN_NOT_BIND, "Could not bind the socket");

    if(protocol == NLProtocol::TCP)
        if(listen(_socket, listenQueue) == -1)
            throw new NLException(ERROR_CAN_NOT_LISTEN, "Could not start listening");


    _isServer = true;
    _isDisconnected = false;
    _blocking = false;
    _protocol = protocol;
    _ipVer = ipVer;
    if(ipVer == NLIpVer::Any) {
        if(ai_family == AF_INET)
            _ipVer = NLIpVer::IPv4;
        else if(ai_family == AF_INET6)
            _ipVer = NLIpVer::IPv6;
    }
    // NO HOST
    _port = port;

    freeaddrinfo(res);
}

NLSocket::NLSocket(int handle, string host, int ipVer) : _host(host) {

    _socket = handle;
    _isServer = false;
    _isDisconnected = false;
    _protocol = NLProtocol::TCP;
    _ipVer = ipVer;
    _port = -1;

}


NLSocket::~NLSocket() {

    close(_socket);
}


NLSocket* NLSocket::accept() {

    if(!_isServer)
        throw new NLException(ERROR_SOCKET_NOT_SERVER, "A non-server socket can not accept connections");

    if(_protocol != NLProtocol::TCP)
        throw new NLException(ERROR_SOCKET_NOT_TCP, "A non-tcp socket can not accept connections");

    struct sockaddr_storage incoming_addr;

    #ifdef OS_WIN32
        int addrSize = sizeof(incoming_addr);
    #else
        unsigned addrSize = sizeof(incoming_addr);
    #endif

    int new_handler = ::accept(_socket, (struct sockaddr *)&incoming_addr, &addrSize);

    if(new_handler == -1)
        return NULL;

    char hostChar[INET6_ADDRSTRLEN];

    inet_ntop(incoming_addr.ss_family, get_in_addr((struct sockaddr *)&incoming_addr), hostChar, sizeof hostChar);

    string host(hostChar);

    NLSocket *newSocket = new NLSocket(new_handler, host, _ipVer);
    newSocket->blocking(_blocking);

    return(newSocket);

}


string& NLSocket::read(unsigned bufferSize, string* hostFrom) {

    if(_isDisconnected)
        throw new NLException(ERROR_SOCKET_DISCONNECTED, "The remote side has already closed the connection");

	#ifdef _MSC_VER
		char *buffer = new char[bufferSize];
	#else
		char buffer[bufferSize];
	#endif

    int status = -1;

    if(hostFrom!= NULL) {

        if(_protocol != NLProtocol::UDP)
            throw new NLException(ERROR_SOCKET_NOT_UDP, "rawRead: hostFrom parameter is only for UDP connections");
        struct sockaddr_storage addr;
        socklen_t fromlen = sizeof addr;
        status = recvfrom(_socket, buffer, bufferSize - 1, 0, (struct sockaddr *)&addr, &fromlen);

        char hostChar[INET6_ADDRSTRLEN];
        inet_ntop(addr.ss_family, get_in_addr((struct sockaddr *)&addr), hostChar, sizeof hostChar);

        hostFrom->clear();
        hostFrom->append(hostChar);
    }

    else
        status = recv(_socket, buffer, bufferSize - 1, 0);

    if( status == 0 && _protocol == NLProtocol::TCP)
        _isDisconnected = true;
    else if (status > 0) {          // TODO: ¿Seguro que lee todo (y si hay un \0 por medio) --> Poner un buffer string intermedio y comprobar si los tamaños coinciden.
        buffer[status] = '\0';
        _readBuffer += buffer;
    }

    #ifdef _MSC_VER
        delete buffer;
    #endif

    return(_readBuffer);
}


vector<unsigned char>* NLSocket::rawRead(unsigned bufferSize, string* hostFrom) {

    if(_isDisconnected)
        throw new NLException(ERROR_SOCKET_DISCONNECTED, "The remote side has already closed the connection");

	#ifdef _MSC_VER
		unsigned char *buffer = new unsigned char[bufferSize];
	#else
		unsigned char buffer[bufferSize];
	#endif

    int status = -1;

    if(hostFrom!= NULL) {

        if(_protocol != NLProtocol::UDP)
            throw new NLException(ERROR_SOCKET_NOT_UDP, "rawRead: hostFrom parameter is only for UDP connections");
        struct sockaddr_storage addr;
        socklen_t fromlen = sizeof addr;
        status = recvfrom(_socket, (char*)buffer, bufferSize - 1, 0, (struct sockaddr *)&addr, &fromlen);

        char hostChar[INET6_ADDRSTRLEN];
        inet_ntop(addr.ss_family, get_in_addr((struct sockaddr *)&addr), hostChar, sizeof hostChar);

        hostFrom->clear();
        hostFrom->append(hostChar);
    }

    else
        status = recv(_socket, (char*)buffer, bufferSize - 1, 0);

    if( status == 0 && _protocol == NLProtocol::TCP)
        _isDisconnected = true;
    else if (status > 0) {
        _rawReadBuffer.insert(_rawReadBuffer.end(), buffer, buffer + status);
    }

    #ifdef _MSC_VER
        delete buffer;
    #endif

    return(&_rawReadBuffer);
}

string& NLSocket::readBuffer() {

    return(_readBuffer);
}

vector<unsigned char>* NLSocket::rawReadBuffer() {

    return(&_rawReadBuffer);
}

void NLSocket::clearReadBuffer() {

    _readBuffer = "";
}

void NLSocket::clearRawReadBuffer() {

    _rawReadBuffer.clear();
}


void NLSocket::send(string data) {

    if(_protocol == NLProtocol::UDP) {
        if(!_isServer)
            return(sendTo(_host, _port, data));
        else
            throw new NLException(ERROR_CAN_NOT_SEND, "Socket is UDP Server, can not send (use sendTo instead)");
    } //if

    int status = 0;
    unsigned sentData = 0;

    while (sentData < data.length()) {

        status = ::send(_socket, data.c_str(), data.length() + 1, 0);

        if(status == -1)
            throw new NLException(ERROR_CAN_NOT_SEND, "Error sending data");
        else
            data.erase(0, status);

        sentData = status;

    } //while

}


void NLSocket::rawSend(vector<unsigned char>* data) {

    if(_protocol == NLProtocol::UDP) {
        if(!_isServer)
            return(rawSendTo(_host, _port, data));
        else
            throw new NLException(ERROR_CAN_NOT_SEND, "Socket is UDP Server, can not send (use sendTo instead)");
    } //if

    int status = 0;
    unsigned sentData = 0;

    unsigned char* dataChar;
    dataChar = &(data->front());

    while (sentData < data->size()) {

        status = ::send(_socket,(char*) dataChar + sentData, data->size() - sentData, 0);

        if(status == -1)
            throw new NLException(ERROR_CAN_NOT_SEND, "Error sending data");

        sentData += status;

    } //while

}

void NLSocket::sendTo(string host, int port, string data) {

    if(_protocol != NLProtocol::UDP)
        throw new NLException(ERROR_SOCKET_NOT_UDP, "Only UDP sockets can sendTo");

    struct addrinfo hints;
    struct addrinfo *res;
    memset(&hints, 0, sizeof(hints));

    switch(_ipVer) {

        case NLIpVer::IPv4  :   hints.ai_family = AF_INET;
                                break;
        case NLIpVer::IPv6  :   hints.ai_family = AF_INET6;
                                break;
        default             :   throw new NLException(ERROR_IPVER_BAD_VALUE, "IpVer doesn't have a correct value");
    } // switch

    hints.ai_socktype = SOCK_DGRAM;

    string portStr = IntToString(port);
    int status = getaddrinfo(host.c_str(), portStr.c_str(), &hints, &res);

    if(status != 0) {
        string errorMsg = "Error setting addrInfo: ";
		#ifndef _MSC_VER
			errorMsg += gai_strerror(status);
		#endif
        throw new NLException(ERROR_SETTING_ADDR_INFO, errorMsg);
    }

    status = 0;
    unsigned sentData = 0;

    while (sentData < data.length()) {

        status = ::sendto(_socket, data.c_str(), data.length() + 1, 0, res->ai_addr, res->ai_addrlen);

        if(status == -1)
            throw new NLException(ERROR_CAN_NOT_SEND, "Error sending data");
        else
            data.erase(0, status);

        sentData = status;

    } //while

    freeaddrinfo(res);
}


void NLSocket::rawSendTo(string host, int port, vector<unsigned char>* data) {

    if(_protocol != NLProtocol::UDP)
        throw new NLException(ERROR_SOCKET_NOT_UDP, "Only UDP sockets can sendTo");

    struct addrinfo hints;
    struct addrinfo *res;
    memset(&hints, 0, sizeof(hints));

    switch(_ipVer) {

        case NLIpVer::IPv4  :   hints.ai_family = AF_INET;
                                break;
        case NLIpVer::IPv6  :   hints.ai_family = AF_INET6;
                                break;
        default             :   throw new NLException(ERROR_IPVER_BAD_VALUE, "IpVer doesn't have a correct value");
    } // switch

    hints.ai_socktype = SOCK_DGRAM;

    string portStr = IntToString(port);
    int status = getaddrinfo(host.c_str(), portStr.c_str(), &hints, &res);

    if(status != 0) {
        string errorMsg = "Error setting addrInfo: ";
		#ifndef _MSC_VER
			errorMsg += gai_strerror(status);
		#endif
        throw new NLException(ERROR_SETTING_ADDR_INFO, errorMsg);
    }

    status = 0;
    unsigned sentData = 0;

    unsigned char* dataChar;
    dataChar = &(data->front());

    while (sentData < data->size()) {

        status = ::sendto(_socket,(char*) dataChar + sentData, data->size(), 0, res->ai_addr, res->ai_addrlen);

        if(status == -1)
            throw new NLException(ERROR_CAN_NOT_SEND, "Error sending data");

        sentData += status;

    } //while

    freeaddrinfo(res);
}


bool NLSocket::isDisconnected() {

    return(_isDisconnected);
}

int NLSocket::protocol() {

    return(_protocol);
}

string NLSocket::host() {

    return(_host);
}

int NLSocket::port() {

    return(_port);
}

bool NLSocket::isServer() {

    return(_isServer);
}

void NLSocket::blocking(bool blck) {


    int result = -1;

    #ifdef OS_WIN32

        u_long non_blocking = !blck;
        result = ioctlsocket(_socket, FIONBIO, &non_blocking);
        if(result!=0)
            result = -1;
    #else

        int flags = fcntl(_socket, F_GETFL);

        if(blck)
            result = fcntl(_socket, F_SETFL, flags & ~O_NONBLOCK);
        else
            result = fcntl(_socket, F_SETFL, flags | O_NONBLOCK);


    #endif

    _blocking = blck;

    if (result == -1)
        throw new NLException(ERROR_CAN_NOT_SET_FLAGS, "Could not set socket flags");

}

bool NLSocket::blocking() {

    return(_blocking);
}

int NLSocket::handle() {

    return(_socket);
}

void NLSocket::close(int handle) {

    #ifdef OS_WIN32

        closesocket(handle);

    #else

        ::close(handle);

    #endif
}


void NLSocket::operator << (string& data) {

    send(data);
}

void NLSocket::operator << (vector<unsigned char>& data) {

    rawSend(&data);
}

void NLSocket::operator >> (string& output) {

    output = read();
    clearReadBuffer();
}

void  NLSocket::operator >> (vector<unsigned char>& data) {

    data.clear();
    vector<unsigned char>* raw = rawRead();
    data.insert(data.begin(), raw->begin(), raw->end());
    clearRawReadBuffer();
}
