/*
    NetLink Sockets: Networking C++ library
    Copyright 2010 Pedro Francisco Pareja Ruiz (PedroPareja@Gmail.com)

    This file is part of NetLink Sockets.

    NetLink Sockets is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NetLink Sockets is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NetLink Sockets. If not, see <http://www.gnu.org/licenses/>.

*/

#ifndef __NL_RPC
#define __NL_RPC

#include "nlException.h"
#include "nlSocket.h"
#include "nlSocketGroup.h"
#include "nlDataBlock.h"

#include <map>
using namespace std;


class NLRPC { //only to contain RPC related constants

    public:

        static bool initDone;

        // DataBlock Ids
        static const unsigned DATABLOCK_ID_EXEC_REQUEST = 20;
        static const unsigned DATABLOCK_ID_THROW_EXCEPTION = 21;
        static const unsigned DATABLOCK_ID_VOID = 22;


        static NLDataBlockDef* DATABLOCK_DEF_EXEC_REQUEST;
        static NLDataBlockDef* DATABLOCK_DEF_THROW_EXCEPTION;
        static NLDataBlockDef* DATABLOCK_DEF_VOID;

        // ERRORS
        static const int ERROR_FUNCTION_NOT_FOUND = 41;
        static const int ERROR_COULD_NOT_CONNECT = 42;
        static const int ERROR_WRONG_PARAMETERS = 43;
        static const int ERROR_EXEC_REQUEST_EXPECTED = 44;

        // OTHERS

};


class NLRPCCmd {

    protected:
        unsigned _paramDataBlockId;

    public:

        virtual NLDataBlock* exec(NLDataBlock* parameters)=0;

        void paramDataBlockId(unsigned paramDataBlockId);
        unsigned paramDataBlockId();
};


class NLRPCServer {

    protected:

        NLDataBlockDefSet _dataBlockDefsSet;
        map<unsigned, NLRPCCmd*> _cmds;
        NLSocket _socket;
        NLSocketGroup _connections;


    public:

        NLRPCServer(int port, int protocol = NLProtocol::TCP, int ipVer = NLIpVer::IPv4);

        void addFunction(unsigned functionId, NLDataBlockDef* paramDataBlockDef, NLRPCCmd* cmd);
        void removeFunction(unsigned functionId);

        void listen(unsigned milisecs);

    protected:

        void processRequest(NLSocket* source);
        void sendAnswer(NLSocket* socket, vector<unsigned char>* raw, string udpHost= "", int udpPort = -1);
        void sendException(NLSocket* socket, int code, string text, string udpHost = "", int udpPort = -1);

        friend class CmdOnRead;
};


class NLRPCClient {

    protected:

        NLSocket _socket;
        NLSocket* _udpListenSocket;     // used in case of an UDP connection
        NLSocketGroup _sGroup;

        NLDataBlockDefSet _defs;
        NLDataBlock* _lastAnswer;

    public:

        NLRPCClient(string host, int port, int protocol = NLProtocol::TCP, int ipVer = NLIpVer::IPv4, int UDPListenPort = -1);  // UDPListenPort only in case of being using UDP protocol for the connection

        void addDataBlockDef(NLDataBlockDef* def);

        NLDataBlock* exec(unsigned functionId, NLDataBlock* parameters, unsigned responseTimeOut);  // returns NULL if timeout
        NLDataBlock* getAnswer(unsigned timeOut);   // To use when an exec call timeouts for the answer. This function is to try to get the answer again.

        friend class ClientOnRead;

    protected:

        void checkException();
};

#endif
