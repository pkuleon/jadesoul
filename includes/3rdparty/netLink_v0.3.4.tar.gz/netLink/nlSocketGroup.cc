/*
    NetLink Sockets: Networking C++ library
    Copyright 2010 Pedro Francisco Pareja Ruiz (PedroPareja@Gmail.com)

    This file is part of NetLink Sockets.

    NetLink Sockets is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NetLink Sockets is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NetLink Sockets. If not, see <http://www.gnu.org/licenses/>.

*/

#include "nlSocketGroup.h"

//aux

#ifndef _MSC_VER

int max(int a, int b) {

    return(a>b?a:b);
}

#endif

// returns miliseconds
unsigned getTime() {

    #ifdef OS_WIN32

        SYSTEMTIME now;
        GetSystemTime(&now);
        unsigned milisec = now.wHour *3600*1000 + now.wMinute *60*1000 + now.wSecond *1000 + now.wMilliseconds;
        return(milisec);

    #else

        struct timeval now;
        gettimeofday(&now, NULL);
        unsigned milisec = now.tv_sec * 1000 + now.tv_usec / 1000.0;
        return(milisec);

    #endif

}


NLSocketGroup::NLSocketGroup() {

    _cmdOnAccept = NULL;
    _cmdOnRead = NULL;
    _cmdOnDisconnect = NULL;

}

NLSocketGroup::NLSocketGroup(const NLSocketGroup& sGroup) : _sockets(sGroup._sockets) {

    _cmdOnAccept = sGroup._cmdOnAccept;
    _cmdOnRead = sGroup._cmdOnRead;
    _cmdOnDisconnect = sGroup._cmdOnDisconnect;

}

void NLSocketGroup::addSocket(NLSocket *socket) {

    _sockets.push_back(socket);

}

NLSocket* NLSocketGroup::getSocket(unsigned i) {

    if(i < _sockets.size())
        return(_sockets[i]);

    return NULL;
}

NLSocket* NLSocketGroup::getSocketbyHandle(int handle) {


    for(unsigned i=0; i < _sockets.size(); i++)
        if(_sockets[i]->handle() == handle)
            return(_sockets[i]);

    return NULL;

}

void NLSocketGroup::removeSocket(unsigned i) {

    if(i < _sockets.size())
        _sockets.erase(_sockets.begin() + i);
}


void NLSocketGroup::removeSocket(NLSocket* socket) {

    unsigned i=0;
    bool borrado = false;

    while(!borrado && i < _sockets.size()) {

        if(_sockets[i] == socket) {
            removeSocket(i);
            borrado = true;
        }
        i++;
    } //while

}

unsigned NLSocketGroup::numSockets() {

    return(_sockets.size());
}


void NLSocketGroup::setCmdOnAccept(NLCmdOnAccept* cmd) {

    _cmdOnAccept = cmd;
}

void NLSocketGroup::setCmdOnRead(NLCmdOnRead* cmd) {

    _cmdOnRead = cmd;
}

void NLSocketGroup::setCmdOnDisconnect(NLCmdOnDisconnect* cmd) {

    _cmdOnDisconnect = cmd;
}

void NLSocketGroup::listen(unsigned milisec, void* reference) {

    unsigned finTime = getTime() + milisec;
    bool executedOnce = false;

    while(getTime() < finTime || !executedOnce) {

        executedOnce = true;

        fd_set setSockets;
        int maxHandle = 0;

        FD_ZERO(&setSockets);

        for(unsigned i=0; i < _sockets.size(); i++) {
            FD_SET(_sockets[i]->handle(), &setSockets);
            maxHandle = max(maxHandle, _sockets[i]->handle());
        }

        unsigned milisecLeft = finTime - getTime();
        struct timeval timeout;

        timeout.tv_sec = milisecLeft / 1000;
        timeout.tv_usec = (milisecLeft % 1000) * 1000;

        int status = select(maxHandle + 1, &setSockets, NULL, NULL, &timeout);

        if (status == -1)
            throw new NLException(ERROR_IN_SELECT, "Could not perform socket select");

        unsigned i=0;
        int launchSockets = 0;

        while(launchSockets < status && i < _sockets.size()) {

            if(FD_ISSET(_sockets[i]->handle(), &setSockets)) {

                launchSockets++;

                if(_sockets[i]->isServer() && _sockets[i]->protocol() == NLProtocol::TCP) {
                    if(_cmdOnAccept != NULL)
                        _cmdOnAccept->onAcceptReady(_sockets[i], this, reference);
                } //if
                else {
                    if(_cmdOnRead != NULL)
                        _cmdOnRead->onReadReady(_sockets[i], this, reference);
                    if(_sockets[i]->isDisconnected() && _cmdOnDisconnect != NULL)
                        _cmdOnDisconnect->onDisconnect(_sockets[i], this, reference);
                }

            }

            i++;

        } //while

    } //while

}


bool NLSocketGroup::listenUntilOne(unsigned milisec, void* reference) {

    unsigned finTime = getTime() + milisec;
    bool executedOnce = false;
    bool recievedAnything = false;

    while((getTime() < finTime || !executedOnce) && !recievedAnything ) {

        executedOnce = true;

        fd_set setSockets;
        int maxHandle = 0;

        FD_ZERO(&setSockets);

        for(unsigned i=0; i < _sockets.size(); i++) {
            FD_SET(_sockets[i]->handle(), &setSockets);
            maxHandle = max(maxHandle, _sockets[i]->handle());
        }

        unsigned milisecLeft = finTime - getTime();
        struct timeval timeout;

        timeout.tv_sec = milisecLeft / 1000;
        timeout.tv_usec = (milisecLeft % 1000) * 1000;

        int status = select(maxHandle + 1, &setSockets, NULL, NULL, &timeout);

        if (status == -1)
            throw new NLException(ERROR_IN_SELECT, "Could not perform socket select");

        if (status > 0)
            recievedAnything = true;

        unsigned i=0;
        int launchSockets = 0;

        while(launchSockets < status && i < _sockets.size()) {

            if(FD_ISSET(_sockets[i]->handle(), &setSockets)) {

                launchSockets++;

                if(_sockets[i]->isServer() && _sockets[i]->protocol() == NLProtocol::TCP) {
                    if(_cmdOnAccept != NULL)
                        _cmdOnAccept->onAcceptReady(_sockets[i], this, reference);
                } //if
                else {
                    if(_cmdOnRead != NULL)
                        _cmdOnRead->onReadReady(_sockets[i], this, reference);
                    if(_sockets[i]->isDisconnected() && _cmdOnDisconnect != NULL)
                        _cmdOnDisconnect->onDisconnect(_sockets[i], this, reference);
                }

            }

            i++;

        } //while

    } //while

    return(recievedAnything);

}


NLSocketGroup& NLSocketGroup::operator = (const NLSocketGroup& sGroup) {

    _sockets = sGroup._sockets;
    _cmdOnAccept = sGroup._cmdOnAccept;
    _cmdOnRead = sGroup._cmdOnRead;
    _cmdOnDisconnect = sGroup._cmdOnDisconnect;
    return(*this);
}
