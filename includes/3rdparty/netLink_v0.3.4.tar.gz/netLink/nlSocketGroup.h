/*
    NetLink Sockets: Networking C++ library
    Copyright 2010 Pedro Francisco Pareja Ruiz (PedroPareja@Gmail.com)

    This file is part of NetLink Sockets.

    NetLink Sockets is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NetLink Sockets is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NetLink Sockets. If not, see <http://www.gnu.org/licenses/>.

*/

#ifndef __NL_SOCKET_GROUP
#define __NL_SOCKET_GROUP

#include "nlException.h"
#include "nlSocket.h"


#include <vector>
using namespace std;

class NLSocket;
class NLSocketGroup;

class NLCmdOnAccept {

    public:
        virtual void onAcceptReady(NLSocket* socket, NLSocketGroup* sGroup, void* reference)=0;
};


class NLCmdOnRead {

    public:
        virtual void onReadReady(NLSocket* socket, NLSocketGroup* sGroup, void* reference)=0;
};


class NLCmdOnDisconnect {

    public:
        virtual void onDisconnect(NLSocket* socket, NLSocketGroup* sGroup, void* reference)=0;
};

class NLSocketGroup {


    protected:

        vector<NLSocket*> _sockets;
        NLCmdOnAccept* _cmdOnAccept;
        NLCmdOnRead* _cmdOnRead;
        NLCmdOnDisconnect* _cmdOnDisconnect;

    public:

        NLSocketGroup();
        NLSocketGroup(const NLSocketGroup& sGroup);

        NLSocketGroup& operator = (const NLSocketGroup& sGroup);

        void addSocket(NLSocket *socket);
        NLSocket* getSocket(unsigned i);
        NLSocket* getSocketbyHandle(int handle);
        void removeSocket(NLSocket *socket);
        void removeSocket(unsigned i);

        unsigned numSockets();

        void setCmdOnAccept(NLCmdOnAccept* cmd);
        void setCmdOnRead(NLCmdOnRead* cmd);
        void setCmdOnDisconnect(NLCmdOnDisconnect* cmd);

        void listen(unsigned milisec, void* reference = NULL);
        bool listenUntilOne(unsigned milisec, void* reference = NULL);      //Returns true if something has been received. False in case timeouts.

    // Const


        static const int ERROR_IN_SELECT = 30;

};


unsigned getTime();



#endif
