/*
    NetLink Sockets: Networking C++ library
    Copyright 2010 Pedro Francisco Pareja Ruiz (PedroPareja@Gmail.com)

    This file is part of NetLink Sockets.

    NetLink Sockets is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NetLink Sockets is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NetLink Sockets. If not, see <http://www.gnu.org/licenses/>.

*/

#include "nlDataBlock.h"

NLDataBlockDef::NLDataBlockDef(unsigned id): _id(id) {}

NLDataBlockDef::NLDataBlockDef(unsigned id, int type, unsigned n, NLDataBlockDef* def): _id(id) {

    checkType(type);

    _dataName.assign(n, "");
    _dataType.assign(n, type);
    _blockDefs.assign(n, def);
}

unsigned NLDataBlockDef::addType(int type, NLDataBlockDef* def) {

    checkType(type);

    _dataName.push_back("");
    _dataType.push_back(type);
    _blockDefs.push_back(def);

    return(_dataType.size()-1);
}

unsigned NLDataBlockDef::addType(string name, int type, NLDataBlockDef* def) {

    checkType(type);

    _dataName.push_back(name);
    _dataType.push_back(type);
    _blockDefs.push_back(def);

    return(_dataType.size()-1);
}

int NLDataBlockDef::getType(unsigned pos) {

    if(pos >= _dataType.size())
        throw new NLException(ERROR_BAD_POSITION, "Position requested is out of vector range");

    return _dataType[pos];
}

int NLDataBlockDef::getType(string name) {

    unsigned pos = getPos(name);

    return(getType(pos));

}

unsigned NLDataBlockDef::getPos(string name) {

    for(unsigned i=0; i < _dataName.size(); i++)
        if(_dataName[i].compare(name) == 0)
            return(i);

    throw new NLException(ERROR_NAME_NOT_FOUND, "Field Name not found on dataBlockDefinition");
}

unsigned NLDataBlockDef::id() {

    return(_id);
}


unsigned NLDataBlockDef::size() {

    return(_dataType.size());
}

void NLDataBlockDef::checkType(int type) {

    if(type > NLDataType::MAX_TYPE || type < NLDataType::MIN_TYPE)
        throw new NLException(ERROR_BAD_TYPE, "Data type incorrect");
}


NLDataBlockDef* NLDataBlockDef::getSubDataBlockDef(unsigned pos) {

    if(pos >= _blockDefs.size())
        throw new NLException(ERROR_BAD_POSITION, "Position requested is out of vector range");

    if(_dataType[pos] != NLDataType::DATA_BLOCK)
        throw new NLException(ERROR_NOT_DATABLOCK_POSITION, "Type in requested position is not a DataBlock");

    return(_blockDefs[pos]);

}

NLDataBlock::NLDataBlock(NLDataBlockDef* def) {

    _blockDef = def;
    _data.assign(def->size(), NULL);
}

NLDataBlock::NLDataBlock() {}

NLDataBlock::NLDataBlock(const NLDataBlock& dB) : _blockDef(dB._blockDef) {

    _data.assign(_blockDef->size(), NULL);

    for(unsigned i=0; i < _data.size(); i++)
        if(dB._data[i] != NULL)
            set(i, dB._data[i]);

}

NLDataBlock::~NLDataBlock() {

    freeMemory();
}


void NLDataBlock::freeMemory() {

    for(unsigned pos=0; pos < _data.size(); pos++)
      switch(_blockDef->getType(pos)) {

        case NLDataType::CHAR           :   if(_data[pos]!= NULL)
                                                delete (char*)_data[pos];
                                            break;

        case NLDataType::UNSIGNED_CHAR  :   if(_data[pos]!= NULL)
                                                delete (unsigned char*)_data[pos];
                                            break;

        case NLDataType::STRING     :   if(_data[pos]!= NULL)
                                            delete (string*)_data[pos];
                                        break;

        case NLDataType::INT_16     :   if(_data[pos]!= NULL)
                                            delete (int*)_data[pos];
                                        break;

        case NLDataType::INT_32     :   if(_data[pos]!= NULL)
                                            delete (long*)_data[pos];
                                        break;

        case NLDataType::INT_64     :   if(_data[pos]!= NULL)
                                            delete (long long*)_data[pos];
                                        break;

        case NLDataType::UNSIGNED_16    :   if(_data[pos]!= NULL)
                                                delete (unsigned*)_data[pos];
                                            break;

        case NLDataType::UNSIGNED_32    :   if(_data[pos]!= NULL)
                                                delete (unsigned long*)_data[pos];
                                            break;

        case NLDataType::UNSIGNED_64    :   if(_data[pos]!= NULL)
                                                delete (unsigned long long*)_data[pos];
                                            break;

        case NLDataType::FLOAT      :   if(_data[pos]!= NULL)
                                            delete (float*)_data[pos];
                                        break;

        case NLDataType::DOUBLE     :   if(_data[pos]!= NULL)
                                            delete (double*)_data[pos];
                                        break;

        case NLDataType::DOUBLE_64  :   if(_data[pos]!= NULL)
                                            delete (long double*)_data[pos];
                                        break;

      } //switch

}


NLDataBlock& NLDataBlock::operator = (const NLDataBlock& dB) {

    freeMemory();

    _blockDef = dB._blockDef;

    _data.assign(_blockDef->size(), NULL);

    for(unsigned i=0; i < _data.size(); i++)
        if(dB._data[i] != NULL)
            set(i, dB._data[i]);

    return(*this);
}


void NLDataBlock::set(unsigned pos, void* data) {

    if(pos >= _blockDef->size())
        throw new NLException(ERROR_BAD_POSITION, "Trying to set data in a position out of the range of dataBlockDefinition");

    int type = _blockDef->getType(pos);

    switch(type) {

        case NLDataType::CHAR           :   if(_data[pos]!= NULL)
                                                delete (char*)_data[pos];
                                            _data[pos] = new char(*(char*)data);
                                            break;

        case NLDataType::UNSIGNED_CHAR  :   if(_data[pos]!= NULL)
                                                delete (unsigned char*)_data[pos];
                                            _data[pos] = new unsigned char(*(unsigned char*)data);
                                            break;

        case NLDataType::STRING     :   if(_data[pos]!= NULL)
                                            delete (string*)_data[pos];
                                        _data[pos] = new string(*(string*)data);
                                        break;

        case NLDataType::INT_16     :   if(_data[pos]!= NULL)
                                            delete (int*)_data[pos];
                                        _data[pos] = new int(*(int*)data);
                                        break;

        case NLDataType::INT_32     :   if(_data[pos]!= NULL)
                                            delete (long*)_data[pos];
                                        _data[pos] = new long(*(long*)data);
                                        break;

        case NLDataType::INT_64     :   if(_data[pos]!= NULL)
                                            delete (long long*)_data[pos];
                                        _data[pos] = new long long(*(long long*)data);
                                        break;

        case NLDataType::UNSIGNED_16    :   if(_data[pos]!= NULL)
                                                delete (unsigned*)_data[pos];
                                            _data[pos] = new unsigned(*(unsigned*)data);
                                            break;

        case NLDataType::UNSIGNED_32    :   if(_data[pos]!= NULL)
                                                delete (unsigned long*)_data[pos];
                                            _data[pos] = new unsigned long(*(unsigned long*)data);
                                            break;

        case NLDataType::UNSIGNED_64    :   if(_data[pos]!= NULL)
                                                delete (unsigned long long*)_data[pos];
                                            _data[pos] = new unsigned long long(*(unsigned long long*)data);
                                            break;

        case NLDataType::FLOAT      :   if(_data[pos]!= NULL)
                                            delete (float*)_data[pos];
                                        _data[pos] = new float(*(float*)data);
                                        break;

        case NLDataType::DOUBLE     :   if(_data[pos]!= NULL)
                                            delete (double*)_data[pos];
                                        _data[pos] = new double(*(double*)data);
                                        break;

        case NLDataType::DOUBLE_64  :   if(_data[pos]!= NULL)
                                            delete (long double*)_data[pos];
                                        _data[pos] = new long double(*(long double*)data);
                                        break;

        case NLDataType::DATA_BLOCK :   _data[pos] = data;
                                        break;

        default                 :   throw new NLException(ERROR_BAD_TYPE, "Type in dataBlockDef incorrect");

    }

}


void NLDataBlock::set(string name, void *data) {

    unsigned pos = _blockDef->getPos(name);
    set(pos, data);
}


void* NLDataBlock::get(unsigned pos) {

    if (pos >= _data.size())
        throw new NLException(ERROR_BAD_POSITION, "trying to get an out of range position");

    return(_data[pos]);
}

void* NLDataBlock::get(string name) {

    unsigned pos = _blockDef->getPos(name);

    return(get(pos));
}


vector<unsigned char>* NLDataBlock::encode(unsigned bufferSize) {


    vector<unsigned char> *rawData = new vector<unsigned char>;

    unsigned char *buffer = new unsigned char[bufferSize];

    pack(buffer, "H", _blockDef->id());
    rawData->insert(rawData->begin(), buffer, buffer + 2);

    for(unsigned i=0; i < _data.size(); i++) {

        if (_data[i] == NULL)
            throw new NLException(ERROR_UNSET_DATA, "Can not encode a block with unset data");

        unsigned packetSize= 0;

        switch(_blockDef->getType(i)) {

            case NLDataType::CHAR   :   packetSize = pack(buffer, "c", *(char*)_data[i]);
                                        break;

            case NLDataType::UNSIGNED_CHAR  :   packetSize = pack(buffer, "C", *(unsigned char*)_data[i]);
                                                break;

            case NLDataType::STRING :   if( ((string*)_data[i])->size() >= ENCODE_BUFFER_SIZE)
                                            throw new NLException(ERROR_STRING_TOO_BIG, "String too big to be encoded");
                                        packetSize = pack(buffer, "s", ((string*)_data[i])->c_str());
                                        break;

            case NLDataType::INT_16 :   packetSize = pack(buffer, "h", *(int*)_data[i]);
                                        break;

            case NLDataType::INT_32 :   packetSize = pack(buffer, "l", *(long*)_data[i]);
                                        break;

            case NLDataType::INT_64 :   packetSize = pack(buffer, "q", *(long long*)_data[i]);
                                        break;

            case NLDataType::UNSIGNED_16    :   packetSize = pack(buffer, "H", *(unsigned*)_data[i]);
                                                break;

            case NLDataType::UNSIGNED_32    :   packetSize = pack(buffer, "L", *(unsigned long*)_data[i]);
                                                break;

            case NLDataType::UNSIGNED_64    :   packetSize = pack(buffer, "Q", *(unsigned long long*)_data[i]);
                                                break;

            case NLDataType::FLOAT  :   packetSize = pack(buffer, "f", *(float*)_data[i]);
                                        break;

            case NLDataType::DOUBLE :   packetSize = pack(buffer, "d", *(double*)_data[i]);
                                        break;

            case NLDataType::DOUBLE_64  :   packetSize = pack(buffer, "g", *(long double*)_data[i]);
                                            break;

            case NLDataType::DATA_BLOCK :   break;

            default                 :   throw new NLException(ERROR_BAD_TYPE, "Type in dataBlockDef incorrect");


        } // switch

        rawData->insert(rawData->end(), buffer, buffer + packetSize);


    } //for


    // We insert sub-dataBlocks here

    for (unsigned i=0; i < _data.size(); i++)
        if(_blockDef->getType(i) == NLDataType::DATA_BLOCK) {
            vector<unsigned char>* subRawData = ((NLDataBlock*)_data[i])->encode(bufferSize);
            rawData->insert(rawData->end(), subRawData->begin(), subRawData->end());
            delete subRawData;
        }

    // ------

    unsigned tama = rawData->size() + 2;

    pack(buffer,"H", tama);
    rawData->insert(rawData->begin(), buffer, buffer + 2);

    delete buffer;

    return(rawData);

}


NLDataBlock::NLDataBlock(vector<unsigned char>* datablockRaw, NLDataBlockDefSet* defs, unsigned* lengthOfRead) {

    unsigned char *rawArray;
    rawArray = &(datablockRaw->front());
    buildFromArray(rawArray, defs, lengthOfRead);
}



void NLDataBlock::buildFromArray(unsigned char* rawArray, NLDataBlockDefSet* defs, unsigned* lengthOfRead) {


    unsigned rawBlockSize=0, rawBlockId=0;

    unpack(rawArray, "HH", &rawBlockSize, &rawBlockId);

    if(lengthOfRead != NULL)
        *lengthOfRead = rawBlockSize;

    NLDataBlockDef* def = defs->get(rawBlockId);

    _blockDef = def;

    if(def == NULL)
        throw new NLException(ERROR_DATABLOCKDEF_NOT_FOUND, "DataBlockDef with id provided by the dataBlock was not found in the DataBlockDefSet");

     _data.assign(def->size(), NULL);

    unsigned char *posAct = rawArray + 4;

    for(unsigned i=0; i < def->size(); i++) {
        switch(def->getType(i)) {

            case NLDataType::CHAR           :   {char data_c;
                                                unpack(posAct, "c", &data_c);
                                                set(i, &data_c);
                                                posAct += 1;}
                                                break;

            case NLDataType::UNSIGNED_CHAR  :   {unsigned char data_C;
                                                unpack(posAct, "C", &data_C);
                                                set(i, &data_C);
                                                posAct += 1;}
                                                break;


            case NLDataType::STRING         : { unsigned stringLength;
                                                unpack(posAct, "H", &stringLength);
                                                char *data_s = new char[stringLength + 1];
                                                unpack(posAct, "s", data_s);
                                                data_s[stringLength] = '\0';
                                                string data_string(data_s);
                                                set(i, &data_string);
                                                delete data_s;
                                                posAct += stringLength + 2;
                                              }
                                                break;


            case NLDataType::INT_16         :   {int data_h;
                                                unpack(posAct, "h", &data_h);
                                                set(i, &data_h);
                                                posAct += 2;}
                                                break;

            case NLDataType::INT_32         :   {long data_l;
                                                unpack(posAct, "l", &data_l);
                                                set(i, &data_l);
                                                posAct += 4;}
                                                break;

            case NLDataType::INT_64         :   {long long data_q;
                                                unpack(posAct, "q", &data_q);
                                                set(i, &data_q);
                                                posAct += 8;}
                                                break;

            case NLDataType::UNSIGNED_16    :   {unsigned data_H;
                                                unpack(posAct, "H", &data_H);
                                                set(i, &data_H);
                                                posAct += 2;}
                                                break;

            case NLDataType::UNSIGNED_32    :   {unsigned long data_L;
                                                unpack(posAct, "L", &data_L);
                                                set(i, &data_L);
                                                posAct += 4;}
                                                break;

            case NLDataType::UNSIGNED_64    :   {unsigned long long data_Q;
                                                unpack(posAct, "Q", &data_Q);
                                                set(i, &data_Q);
                                                posAct += 8;}
                                                break;

            case NLDataType::FLOAT          :   {float data_f;
                                                unpack(posAct, "f", &data_f);
                                                set(i, &data_f);
                                                posAct += 2;}
                                                break;

            case NLDataType::DOUBLE         :   {double data_d;
                                                unpack(posAct, "d", &data_d);
                                                set(i, &data_d);
                                                posAct += 4;}
                                                break;

            case NLDataType::DOUBLE_64      :   {long double data_g;
                                                unpack(posAct, "g", &data_g);
                                                set(i, &data_g);
                                                posAct += 8;}
                                                break;

            case NLDataType::DATA_BLOCK     :   break;

            default                         :   throw new NLException(ERROR_BAD_TYPE, "Type in dataBlockDef incorrect");

        } // switch

    if (posAct - rawArray > rawBlockSize)
        throw new NLException(ERROR_BAD_RAW_BLOCK_SIZE, "Size of raw datablock does not match");

    } //for

    // Read sub-RawBlocks

    for(unsigned i=0; i < _blockDef->size(); i++)
        if(_blockDef->getType(i)==NLDataType::DATA_BLOCK) {
            _data[i] = new NLDataBlock();
            unsigned blockSize;
            ((NLDataBlock*)_data[i])->buildFromArray(posAct, defs, &blockSize);
            posAct += blockSize;
        } //if
}


void NLDataBlock::setInt(string name, long long data) {

    unsigned pos = _blockDef->getPos(name);
    setInt(pos, data);
}

void NLDataBlock::setInt(unsigned pos, long long data) {

    int type = _blockDef->getType(pos);

    switch(type) {

        case NLDataType::CHAR   :   {char* dataPointer = new char(data);
                                    set(pos, dataPointer);
                                    delete dataPointer;
                                    break;}

        case NLDataType::INT_16 :   {int* dataPointer = new int(data);
                                    set(pos, dataPointer);
                                    delete dataPointer;
                                    break;}

        case NLDataType::INT_32 :   {long int* dataPointer = new long int(data);
                                    set(pos, dataPointer);
                                    delete dataPointer;
                                    break;}


        case NLDataType::INT_64 :   {long long int* dataPointer = new long long int(data);
                                    set(pos, dataPointer);
                                    delete dataPointer;
                                    break;}

        default                 :   throw new NLException(ERROR_BAD_TYPE, "setInt: position with bad Type!!");

    } //switch
}


void NLDataBlock::setDouble(string name, long double data) {

    unsigned pos = _blockDef->getPos(name);
    setDouble(pos, data);
}


void NLDataBlock::setDouble(unsigned pos, long double data) {

    int type = _blockDef->getType(pos);

    switch(type) {

        case NLDataType::FLOAT :   {float* dataPointer = new float(data);
                                    set(pos, dataPointer);
                                    delete dataPointer;
                                    break;}

        case NLDataType::DOUBLE :   {double* dataPointer = new double(data);
                                    set(pos, dataPointer);
                                    delete dataPointer;
                                    break;}

        case NLDataType::DOUBLE_64  :   {long double* dataPointer = new long double(data);
                                        set(pos, dataPointer);
                                        delete dataPointer;
                                        break;}

        default                 :   throw new NLException(ERROR_BAD_TYPE, "setDouble: position with bad Type!!");

    } //switch

}


void NLDataBlock::setUnsigned(string name, unsigned long long data) {

    unsigned pos = _blockDef->getPos(name);
    setUnsigned(pos, data);
}


void NLDataBlock::setUnsigned(unsigned pos, unsigned long long data) {

    int type = _blockDef->getType(pos);

    switch(type) {

        case NLDataType::UNSIGNED_CHAR   :   {unsigned char* dataPointer = new unsigned char(data);
                                                set(pos, dataPointer);
                                                delete dataPointer;
                                                break;}

        case NLDataType::UNSIGNED_16     :   {unsigned int* dataPointer = new unsigned int(data);
                                                set(pos, dataPointer);
                                                delete dataPointer;
                                                break;}

        case NLDataType::UNSIGNED_32    :   {unsigned long int* dataPointer = new unsigned long int(data);
                                                set(pos, dataPointer);
                                                delete dataPointer;
                                                break;}


        case NLDataType::UNSIGNED_64    :   {unsigned long long int* dataPointer = new unsigned long long int(data);
                                                set(pos, dataPointer);
                                                delete dataPointer;
                                                break;}

        default                 :   throw new NLException(ERROR_BAD_TYPE, "setUnsigned: position with bad Type!!");

    } //switch
}


void NLDataBlock::setString(string name, string data) {

    unsigned pos = _blockDef->getPos(name);
    setString(pos, data);
}


void NLDataBlock::setString(unsigned pos, string data) {

    int type = _blockDef->getType(pos);

    if(type != NLDataType::STRING)
        throw new NLException(ERROR_BAD_TYPE, "setString: position with bad Type!!");

    set(pos, &data);
}

void NLDataBlock::setSubDataBlock(string name, NLDataBlock* data) {

    unsigned pos = _blockDef->getPos(name);
    setSubDataBlock(pos, data);
}

void NLDataBlock::setSubDataBlock(unsigned pos, NLDataBlock* data) {

    int type = _blockDef->getType(pos);

    if(type != NLDataType::DATA_BLOCK)
        throw new NLException(ERROR_BAD_TYPE, "setSubDataBlock: position with bad Type!!");


    NLDataBlockDef* dataBlockIdTheoric = _blockDef->getSubDataBlockDef(pos);

    if(dataBlockIdTheoric != NULL)
        if(data->id() != dataBlockIdTheoric->id())
            throw new NLException(ERROR_BAD_DATABLOCK_TYPE, "subDataBlock id does not match with the one set in the main dataBlock definition");

    set(pos, data);
}


long long NLDataBlock::getInt(string name) {

    unsigned pos = _blockDef->getPos(name);
    return(getInt(pos));
}

long long NLDataBlock::getInt(unsigned pos) {

    int type = _blockDef->getType(pos);

    switch(type) {

        case NLDataType::CHAR   :   return (*(char*)get(pos));
                                    break;

        case NLDataType::INT_16 :   return (*(int*)get(pos));
                                    break;


        case NLDataType::INT_32 :   return (*(long int*)get(pos));
                                    break;

        case NLDataType::INT_64 :   return (*(long long int*)get(pos));
                                    break;

        default                 :   throw new NLException(ERROR_BAD_TYPE, "getInt: position with bad Type!!");

    } //switch

    return(0);  //This is never reached. It is only to avoid compiler warning
}


long double NLDataBlock::getDouble(string name) {

    unsigned pos = _blockDef->getPos(name);
    return(getDouble(pos));
}


long double NLDataBlock::getDouble(unsigned pos) {

    int type = _blockDef->getType(pos);

    switch(type) {

        case NLDataType::FLOAT      :   return (*(float*)get(pos));
                                        break;

        case NLDataType::DOUBLE     :   return (*(double*)get(pos));
                                        break;

        case NLDataType::DOUBLE_64  :   return (*(long double*)get(pos));
                                        break;

        default                     :   throw new NLException(ERROR_BAD_TYPE, "getDouble: position with bad Type!!");

    } //switch

    return(0);  //This is never reached. It is only to avoid compiler warning
}


unsigned long long NLDataBlock::getUnsigned(string name) {

    unsigned pos = _blockDef->getPos(name);
    return(getUnsigned(pos));
}


unsigned long long NLDataBlock::getUnsigned(unsigned pos) {

    int type = _blockDef->getType(pos);

    switch(type) {

        case NLDataType::UNSIGNED_CHAR  :   return (*(unsigned char*)get(pos));
                                            break;

        case NLDataType::UNSIGNED_16    :   return (*(unsigned int*)get(pos));
                                            break;

        case NLDataType::UNSIGNED_32    :   return (*(unsigned long int*)get(pos));
                                            break;

        case NLDataType::UNSIGNED_64    :   return (*(unsigned long long int*)get(pos));
                                            break;

        default                 :   throw new NLException(ERROR_BAD_TYPE, "getUnsigned: position with bad Type!!");

    } //switch

    return(0);  //This is never reached. It is only to avoid compiler warning
}


string NLDataBlock::getString(string name) {

    unsigned pos = _blockDef->getPos(name);
    return(getString(pos));
}

string NLDataBlock::getString(unsigned pos) {

    int type = _blockDef->getType(pos);

    if(type != NLDataType::STRING)
        throw new NLException(ERROR_BAD_TYPE, "getString: position with bad Type!!");

    return(*(string*)get(pos));
}

NLDataBlock* NLDataBlock::getSubDataBlock(unsigned pos) {

    int type = _blockDef->getType(pos);

    if(type != NLDataType::DATA_BLOCK)
        throw new NLException(ERROR_BAD_TYPE, "setSubDataBlock: position with bad Type!!");

    return((NLDataBlock*)get(pos));
}


NLDataBlock* NLDataBlock::getSubDataBlock(string name) {

    unsigned pos = _blockDef->getPos(name);
    return(getSubDataBlock(pos));
}

bool NLDataBlock::checkRawDataBlock(vector<unsigned char>* dataBlockRaw) {

    unsigned char *rawArray;
    rawArray = &(dataBlockRaw->front());

    unsigned rawBlockSize=0;

    unpack(rawArray, "H", &rawBlockSize);

    return(rawBlockSize <= dataBlockRaw->size());

}

unsigned NLDataBlock::id() {

    return(_blockDef->id());
}


void NLDataBlock::deleteSubDataBlocks() {

    for(unsigned i=0; i < _data.size(); i++)
        if(_blockDef->getType(i)== NLDataType::DATA_BLOCK && _data[i]!=NULL)
            delete (NLDataBlock*)_data[i];

}


NLDataBlockDefSet::NLDataBlockDefSet() {}

void NLDataBlockDefSet::add(NLDataBlockDef* def) {

    _defs[def->id()] = def;
}

NLDataBlockDef* NLDataBlockDefSet::get(unsigned id) {

    if (_defs.find(id) == _defs.end())
        return NULL;

    return(_defs[id]);
}

NLDataBlockDefSet::NLDataBlockDefSet(const NLDataBlockDefSet& dSet) : _defs(dSet._defs) {}

NLDataBlockDefSet& NLDataBlockDefSet::operator = (const NLDataBlockDefSet& dSet) {

    _defs = dSet._defs;
    return(*this);
}

