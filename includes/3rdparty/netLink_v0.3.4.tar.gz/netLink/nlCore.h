/*
    NetLink Sockets: Networking C++ library
    Copyright 2010 Pedro Francisco Pareja Ruiz (PedroPareja@Gmail.com)

    This file is part of NetLink Sockets.

    NetLink Sockets is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NetLink Sockets is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NetLink Sockets. If not, see <http://www.gnu.org/licenses/>.

*/


#ifndef __NET_LINK_CORE
#define __NET_LINK_CORE

    #if defined(_WIN32) || defined(__WIN32__) || defined(_MSC_VER)

        #define OS_WIN32
        #define _WIN32_WINNT 0x0600


        #include <winsock2.h>
        #include <ws2tcpip.h>

        // Requires Win7 or Vista
        // Link to Ws2_32.lib library

    #else

        #define OS_LINUX

        #include <arpa/inet.h>
        #include <sys/fcntl.h>
        #include <sys/types.h>
        #include <sys/socket.h>
        #include <sys/unistd.h>
        #include <sys/time.h>
        #include <netdb.h>

    #endif

    #include <string.h>
    #include <time.h>


class NLProtocol {

    public:
        static const int TCP = 1;
        static const int UDP = 2;
};

class NLIpVer {

    public:
        static const int IPv4 = 11;
        static const int IPv6 = 12;
        static const int Any = 13;
};


void nlInit();

#define ERROR_INIT_FAILED 101


#endif

