/*
    NetLink Sockets: Networking C++ library
    Copyright 2010 Pedro Francisco Pareja Ruiz (PedroPareja@Gmail.com)

    This file is part of NetLink Sockets.

    NetLink Sockets is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NetLink Sockets is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NetLink Sockets. If not, see <http://www.gnu.org/licenses/>.

*/

#ifndef __UTIL
#define __UTIL

#include <iostream>
#include <string>
#include <sstream>
#include <ctime>
#include <fstream>
#include <algorithm>

#include <stdlib.h>

using namespace std;

	void error(string desc, int code);

    string StringToUpper(string cadena);
	string StringToLower(string cadena);

	int StringToInt(string stringValue);
	string IntToString(int iValue);

	unsigned long StringToUnsignedLong(string stringValue);
	string UnsignedLongToString(unsigned long iValue);

	double StringToDouble(string stringValue);
	string DoubleToString(double iValue);

	string fileToString(string fileName);
	void stringToFile(string fileName, string text);



    // si solo se pasa un argumento el numero aleatrio va de 0 a min_or_max
	int randInt(int min_or_max, int max = -1);



#endif
