/*
    NetLink Sockets: Networking C++ library
    Copyright 2010 Pedro Francisco Pareja Ruiz (PedroPareja@Gmail.com)

    This file is part of NetLink Sockets.

    NetLink Sockets is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NetLink Sockets is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NetLink Sockets. If not, see <http://www.gnu.org/licenses/>.

*/

#include "util.h"

int randInicializado = 0;


void error(string desc, int code) {

        cout << desc;
        exit(code);
}

int StringToInt(string stringValue)
{
    std::stringstream ssStream(stringValue);
    int iReturn;
    ssStream >> iReturn;

    return iReturn;
}

string IntToString(int iValue)
{
    std::stringstream ssStream;
    ssStream << iValue;
    return ssStream.str();
}


unsigned long StringToUnsignedLong(string stringValue)
{
    std::stringstream ssStream(stringValue);
    unsigned long iReturn;
    ssStream >> iReturn;

    return iReturn;
}


string UnsignedLongToString(unsigned long iValue)
{
    std::stringstream ssStream;
    ssStream << iValue;
    return ssStream.str();
}


double StringToDouble(string stringValue)
{
    std::stringstream ssStream(stringValue);
    double iReturn;
    ssStream >> iReturn;

    return iReturn;
}

string DoubleToString(double iValue)
{
    std::stringstream ssStream;
    ssStream << iValue;
    return ssStream.str();
}

int randInt(int min_or_max, int max) {

    int min = min_or_max;

    if(!randInicializado) {

        srand(time(NULL));
        randInicializado = 1;

    }

    if(max == -1) {

            min = 0;
            max = min_or_max;
    }


    int rango = max - min + 1;

    return(rand()%rango + min);


}

string fileToString(string fileName) {


   ifstream infile(fileName.c_str());

   if (!infile)
   {
      return "";
   }

   string line;
   string result;

   while (getline(infile, line))
   {
      result += line;
   }

   infile.close();


   return result;

}


void stringToFile(string fileName, string text) {


    fstream f(fileName.c_str(), fstream::out);

    f << text;

    f.close();

}


string StringToUpper(string cadena) {

    std::transform(cadena.begin(), cadena.end(), cadena.begin(), (int(*)(int)) toupper);

    return(cadena);

}


string StringToLower(string cadena) {

    std::transform(cadena.begin(), cadena.end(), cadena.begin(), (int(*)(int)) tolower);

    return(cadena);

}


