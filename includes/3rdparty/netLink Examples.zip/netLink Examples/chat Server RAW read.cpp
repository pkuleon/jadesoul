#include <iostream>
#include <vector>

#include "../netLink/netLink.h"

using namespace std;

const int PORT = 3123;

int main()
{

    vector<NLSocket*> _connections;
    bool quit = false;

    cout << "Chat Server!" << endl;

    NLSocket socket(PORT, NLProtocol::TCP, NLIpVer::IPv4);

    socket.blocking(false);

    while(!quit) {

        NLSocket* newConnection = socket.accept();
        if(newConnection != NULL)
            _connections.push_back(newConnection);

        for(unsigned i=0; i < _connections.size(); i++) {
            string host;
            vector<unsigned char>* texto = _connections[i]->rawRead(NLSocket::DEFAULT_BUFFER_SIZE, &host);
            cout << "\nTexto recibido de host(rcvFrom): " << host;
            cout << " del socket de host: " << _connections[i]->host();
            if(texto->size() > 0)
                cout << "\n";
            for (unsigned k=0; k < texto->size(); k++)
                cout << texto->at(k);
            if (texto->size() > 0)
                for(unsigned j=0; j < _connections.size(); j++)
                   if(i!=j)
                        _connections[j]->rawSend(texto);

            _connections[i]->clearRawReadBuffer();
        }

    }

    return 0;
}
