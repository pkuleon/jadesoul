#include <iostream>

#include "../netLink/netLink.h"

using namespace std;

void use(string progName) {

    cout << "\nUse:\n\t" << progName  << " <Local Port> <Remote Host> <Remote Port>\n\n";
}

int main(int argc, char *argv[])
{
    cout << "AdHocChat!" << endl;

    if(argc < 4) {
        use(argv[0]);
        exit(0);
    }

    string localPortStr(argv[1]);
    string host(argv[2]);
    string remotePortStr(argv[3]);

    int localPort = StringToInt(localPortStr);
    int remotePort = StringToInt(remotePortStr);

    NLSocket socket(localPort, NLProtocol::UDP, NLIpVer::IPv4);
    socket.blocking(false);

    bool quit=false;

    while(!quit) {

        string input;
        cin >> input;
        if(input.compare("quit")==0)
            quit = true;
        socket.sendTo(host, remotePort, input);
        string hostFrom;
        string incoming = socket.read(NLSocket::DEFAULT_BUFFER_SIZE, &hostFrom);
        socket.clearReadBuffer();
        if(incoming.size()>0)
            cout << "\nRead: " << incoming << " from: " << hostFrom << "\n";
    }

    return 0;
}
