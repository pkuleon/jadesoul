#include <iostream>
#include <vector>

#include "../netLink/netLink.h"

using namespace std;

const int PORT = 3123;

int main()
{

    vector<NLSocket*> _connections;
    bool quit = false;

    cout << "Chat Server!" << endl;

    NLSocket socket(PORT, NLProtocol::TCP, NLIpVer::IPv4);

    socket.blocking(false);

    while(!quit) {

        NLSocket* newConnection = socket.accept();
        if(newConnection != NULL)
            _connections.push_back(newConnection);

        for(unsigned i=0; i < _connections.size(); i++) {
            string texto(_connections[i]->read());
            _connections[i]->clearReadBuffer();
            cout << texto;
            if (texto.length() > 0)
                for(unsigned j=0; j < _connections.size(); j++)
                   if(i!=j)
                        _connections[j]->send(texto);
        }

    }

    return 0;
}
