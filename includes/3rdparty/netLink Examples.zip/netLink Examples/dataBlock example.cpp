#include "../netLink/netLink.h"

#include <iostream>

using namespace std;

int main()
{
    cout << "NLDataBlock Test!" << endl;

    // Making and defining the Block definition:
    // Notice that we are making 2 blocks. One will be inside the other.

    NLDataBlockDef *subDBDef = new NLDataBlockDef(78);
    subDBDef->addType("a", NLDataType::FLOAT);
    subDBDef->addType("b", NLDataType::INT_32);


    NLDataBlockDef* def = new NLDataBlockDef(25);
    def->addType("minutos", NLDataType::UNSIGNED_64);
    def->addType("nombre", NLDataType::STRING);
    def->addType("edad",NLDataType::INT_16);

    def->addType("porcentaje", NLDataType::DOUBLE);

    def->addType("subBloque", NLDataType::DATA_BLOCK, subDBDef);


    NLDataBlockDefSet set;  // We define a set of block definitions
    set.add(def);           // We add the current block definition we are using to the set
    set.add(subDBDef);      // We add the  subblock definition

    // We create a dataBlock using a block definition

    NLDataBlock dataInput(def);
    NLDataBlock dataInputSubBlock(subDBDef);

    // We set the dataBlock data

    dataInputSubBlock.setDouble("a", 6.326);
    dataInputSubBlock.setInt("b", -54);

    dataInput.setInt("edad", 19);
    dataInput.setDouble("porcentaje", 65.432198);
    dataInput.setString("nombre", "Yoshua Kalamaro");
    dataInput.setUnsigned("minutos", 9827381291);
    dataInput.setSubDataBlock("subBloque", &dataInputSubBlock);


    // We get the data for testing
    int edad = dataInput.getInt("edad");
    double porcentaje = dataInput.getDouble("porcentaje");
    string nombre = dataInput.getString("nombre");
    unsigned long long minutos = dataInput.getUnsigned("minutos");

    cout << "\ndataInput: " << edad << " - " << porcentaje << " - " << nombre << " - " << minutos;


    // This char vector is what we would send over internet
    // Notice: when we encode dataInput we also encode dataInputSubBlock because it is contained in dataInput.

    vector<unsigned char>* packedData = dataInput.encode();


    // We print the vector on the screen
    cout << "\nContenido del vector: ";

    for(unsigned i=0; i < packedData->size(); i++)
        cout << (unsigned)packedData->at(i) << " - ";


    // We create a dataBlock with the char vector (which we should have recieved from the socket) and a set of definitions (the char vector has the id of the block definition needed)
    NLDataBlock dataOutput(packedData, &set);

    // We get the subblock contained inside the main datablock
    NLDataBlock* dataOutputSubBlock = dataOutput.getSubDataBlock("subBloque");

    // We get the data from the dataBlock
    edad = dataOutput.getInt("edad");
    porcentaje = dataOutput.getDouble("porcentaje");
    nombre = dataOutput.getString("nombre");
    minutos = dataOutput.getUnsigned("minutos");

    // we get the subblock data
    float a = dataOutputSubBlock->getDouble("a");
    long b = dataOutputSubBlock->getInt("b");

    cout << "\nDataOutput: " << edad << " - " << porcentaje << " - " << nombre << " - " << minutos;
    cout << "\nDataOutputSubBlock: " << a << " - " << b;

    return 0;
}
