#include <iostream>
#include "../netLink/netLink.h"
using namespace std;

const unsigned WRITE_ON_DISPLAY_FUNCTION_ID = 1000;
const unsigned WRITE_ON_DISPLAY_RETURN_ID = 1001;
NLDataBlockDef* writeOnDisplayReturnDef = new NLDataBlockDef(WRITE_ON_DISPLAY_RETURN_ID);
const unsigned WRITE_ON_DISPLAY_PARAMS_ID = 1002;
NLDataBlockDef* writeOnDisplayParamsDef = new NLDataBlockDef(WRITE_ON_DISPLAY_PARAMS_ID);

void init() {

        writeOnDisplayReturnDef->addType("size", NLDataType::UNSIGNED_16);
        writeOnDisplayParamsDef->addType("text", NLDataType::STRING);
}


class FunctionWriteOnDisplay : public NLRPCCmd {

    NLDataBlock* exec(NLDataBlock* parameters) {

            string textToWrite = parameters->getString("text");
            cout << "\n" << textToWrite;

            NLDataBlock* returnDB = new NLDataBlock(writeOnDisplayReturnDef);
            returnDB->setUnsigned("size", textToWrite.length());
            return(returnDB);
    }
};


int main()
{
    init();

    cout << "RPC Server" << endl;

    int port = 5050;

    NLRPCServer server(port);

    FunctionWriteOnDisplay* cmd = new FunctionWriteOnDisplay();

    server.addFunction(WRITE_ON_DISPLAY_FUNCTION_ID, writeOnDisplayParamsDef, cmd);

    while(true) {

        server.listen(100);
    }

    return 0;
}
