#include <iostream>

#include "../netLink/netLink.h"

using namespace std;

int PORT = 3123;

class OnAccept: public NLCmdOnAccept {

    public:
        OnAccept(){};

        void onAcceptReady(NLSocket* socket, NLSocketGroup* sGroup) {

            NLSocket* newSocket = socket->accept();
            if(newSocket != NULL)
                sGroup->addSocket(newSocket);
        }
};

class OnRead: public NLCmdOnRead {

    public:
        OnRead(){};

        void onReadReady(NLSocket* socket, NLSocketGroup* sGroup) {

            string data = socket->read();
            socket->clearReadBuffer();
            for (unsigned i=0; i < sGroup->numSockets(); i++)
                if(!sGroup->getSocket(i)->isServer() && sGroup->getSocket(i) != socket)
                    sGroup->getSocket(i)->send(data);
        }
};


int main()
{
    cout << "Chat Server 2!" << endl;

    NLSocket server(PORT, NLProtocol::TCP, NLIpVer::IPv4);
    NLSocketGroup group;
    group.addSocket(&server);

    OnAccept cmdAccept;
    OnRead cmdRead;

    group.setCmdOnAccept(&cmdAccept);
    group.setCmdOnRead(&cmdRead);

    bool quit = false;
    unsigned i=0;

    while(!quit) {
        group.listen(1000);
        cout << "\nsecond " << i++;
    }

    return 0;
}
