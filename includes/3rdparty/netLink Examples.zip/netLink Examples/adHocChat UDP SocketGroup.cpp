#include <iostream>

#include "../netLink/netLink.h"

using namespace std;

void use(string progName) {

    cout << "\nUse:\n\t" << progName  << " <Local Port> <Remote Host> <Remote Port>\n\n";
}

class onRead : public NLCmdOnRead {

    public:
        onRead(){}

    void onReadReady(NLSocket* socket, NLSocketGroup* sGroup) {

        string incoming = socket->read();
        socket->clearReadBuffer();
        cout << "\nRead: " << incoming << "\n";
    }

};

int main(int argc, char *argv[])
{
    cout << "AdHocChat2!" << endl;

    if(argc < 4) {
        use(argv[0]);
        exit(0);
    }

    string localPortStr(argv[1]);
    string host(argv[2]);
    string remotePortStr(argv[3]);

    int localPort = StringToInt(localPortStr);
    int remotePort = StringToInt(remotePortStr);

    NLSocket socket(localPort, NLProtocol::UDP, NLIpVer::IPv4);
    NLSocketGroup group;
    group.addSocket(&socket);
    onRead cmdOnRead;
    group.setCmdOnRead(&cmdOnRead);

    bool quit = false;

    while(!quit) {

        string input;
        cin >> input;
        socket.sendTo(host, remotePort, input);
        group.listen(10);
    } //while

    return 0;
}
