#include <iostream>
#include "../netLink/netLink.h"
using namespace std;

const unsigned WRITE_ON_DISPLAY_FUNCTION_ID = 1000;
const unsigned WRITE_ON_DISPLAY_RETURN_ID = 1001;
NLDataBlockDef* writeOnDisplayReturnDef = new NLDataBlockDef(WRITE_ON_DISPLAY_RETURN_ID);
const unsigned WRITE_ON_DISPLAY_PARAMS_ID = 1002;
NLDataBlockDef* writeOnDisplayParamsDef = new NLDataBlockDef(WRITE_ON_DISPLAY_PARAMS_ID);

void init() {

        writeOnDisplayReturnDef->addType("size", NLDataType::UNSIGNED_16);
        writeOnDisplayParamsDef->addType("text", NLDataType::STRING);
}


int main()
{
    init();
    cout << "RPC Client" << endl;

    int port = 5050;

    NLRPCClient rpc("localhost", port);
    rpc.addDataBlockDef(writeOnDisplayReturnDef);

    while(true) {

        cout << "\nInput text: ";
        string textToSend;
        cin >> textToSend;

        NLDataBlock parameters(writeOnDisplayParamsDef);
        parameters.setString("text", textToSend);

        NLDataBlock* answer = rpc.exec(WRITE_ON_DISPLAY_FUNCTION_ID, &parameters, 100);
        if(answer!=NULL) {

            unsigned sizeOfText = answer->getUnsigned("size");
            cout << "Size of sent text (calculated by server) is :" << sizeOfText;
            delete answer;
        }
        else
            cout << "\nTimeout reached before recieving answer from the server...";
    }

    return 0;
}
